from pathlib import Path
import subprocess,json,zipfile
import numpy as np
R=Path(__file__).resolve().parent;O=R/'delivery';movie=O/'Rexo_Brand_Intro_Voiced_v3.mp4'
cues=[(0,2.22,'عندك فكرة مشروع، وجاهز تبدأ؟'),(3.08,4.94,'طيب، مين رح ينفّذ؟'),(4.94,8.34,'بدك موقع، وتطبيق موبايل،\nوبوت يساعد زباينك.'),(8.34,11.58,'ولما كل جزء يكون عند جهة،\nبتزيد المتابعة…'),(11.58,13.12,'مع إن الفكرة وحدة.'),(13.12,16.5,'مع ريكسو، عندك شريك واحد\nلحلولك الرقمية.'),(16.5,20.28,'بنصمّم مواقع وتطبيقات\nتقرّب خدماتك من زبونك،'),(20.28,23.34,'وبنطوّر برمجيات مخصّصة\nعلى مقاس شغلك.'),(23.34,26.4,'ومن المنيو الرقمي\nلأنظمة الطلبات والإدارة،'),(26.4,28.7,'بنسهّل ترتيب التفاصيل ومتابعتها.'),(28.7,31.58,'وببوتات الذكاء الاصطناعي\nوأتمتة المهام،'),(31.58,33.4,'بتخفّف الشغل المتكرّر…'),(33.4,35.06,'وبتعطي وقتك للأهم.'),(35.06,39.14,'وبنربط أنظمتك ببعض،\nحتى تشتغل البيانات والخطوات سوا.'),(39.14,40.66,'شو بيميّز طريقتنا؟'),(40.66,42.04,'حل حسب احتياجك،'),(42.04,45.74,'وخدمات مترابطة،\nوفريق معك من الفكرة للإطلاق.'),(45.74,49.84,'من فهم الفكرة، للتصميم،\nللتطوير… للإطلاق.'),(49.84,50.56,'ريكسو.'),(50.56,52.6,'رؤيتك، وتقنيتنا.'),(52.6,56.52,'احكيلنا عن فكرتك برسالة\nعلى ريكسو دوت ويب، وخلّينا نبدأ.')]
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d},{ms%1000:03d}'
(O/'Rexo_AR.srt').write_text('\n\n'.join(f'{i}\n{stamp(s)} --> {stamp(e)}\n{tx}' for i,(s,e,tx) in enumerate(cues,1))+'\n')
def pcm(path):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-ac','1','-ar','16000','-f','f32le','-']),np.float32)
a=pcm(R/'voice.mp3');b=pcm(movie);n=min(len(a),len(b));corr=float(np.corrcoef(a[:n],b[:n])[0,1]);assert corr>.97,corr
lags={i:float(np.corrcoef(a[16000:32000],b[16000+i:32000+i])[0,1]) for i in range(-80,81)}
best=max(lags,key=lags.get);assert abs(best)<=1,best
p=subprocess.run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-'],capture_output=True,text=True);assert p.returncode==0 and not p.stderr,p.stderr
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height,r_frame_rate,sample_rate,duration:format=duration,size','-of','json',str(movie)]))
checks={'full_decode':'pass','source_audio_seconds':len(a)/16000,'export_audio_seconds':len(b)/16000,'zero_lag_waveform_correlation':corr,'best_offset_samples_at_16k':best,'original_audio_speed':1.0,'peak_after_decode':float(np.max(np.abs(b))),'direct_listening_review':'unavailable','streams':info}
(O/'technical-check.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
for t in [15.8,44.7,56]:subprocess.run(['ffmpeg','-y','-v','error','-ss',str(t),'-i',str(movie),'-frames:v','1','-vf','scale=360:640',str(O/f'encoded-{t}.jpg')],check=True)
with zipfile.ZipFile(O/'Rexo_Voiced_Editable_v3.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['render_voiced.py','render_v2.py','base.py','logo-paths.json','voice.mp3','transcript.json','README.md','check_and_package.py']:
  z.write(R/name,'Rexo_Voiced_v3/'+name)
 for f in (R/'assets').iterdir():
  if f.name not in ['brand-symbol.png','logo-proof.jpg']:z.write(f,'Rexo_Voiced_v3/assets/'+f.name)
 for name in ['timeline.json','Rexo_AR.srt','technical-check.json']:z.write(O/name,'Rexo_Voiced_v3/delivery/'+name)
