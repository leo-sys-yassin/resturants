from pathlib import Path
from playwright.sync_api import sync_playwright
import json,math
R=Path(__file__).resolve().parent;A=R/'assets';(A/'scroll').mkdir(exist_ok=True)
coords={}
with sync_playwright() as w:
 b=w.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 p=b.new_page(viewport={'width':432,'height':768},device_scale_factor=2,locale='ar-SY')
 p.add_init_script("localStorage.setItem('ember-language-v1','ar')")
 p.goto('http://127.0.0.1:8876/offline-menu.html');p.wait_for_timeout(1200)
 for i in range(60):
  u=i/59;y=round(480*(u*u*(3-2*u)))
  p.evaluate('(y)=>window.scrollTo(0,y)',y);p.wait_for_timeout(30);p.screenshot(path=str(A/'scroll'/f'{i:03d}.jpg'),type='jpeg',quality=90)
 print('scroll captured',flush=True)
 for cat in ['burgers','shakes']:
  p.locator(f'[data-category="{cat}"]').click();p.wait_for_timeout(1800);p.screenshot(path=str(A/f'{cat}.png'))
 p.locator('[data-category="burgers"]').click();p.wait_for_timeout(1800)
 p.locator('#scene-burgers [data-product]').first.click();p.wait_for_timeout(500)
 p.screenshot(path=str(A/'details.png'))
 p.locator('#productDetails').evaluate('(e)=>e.scrollTop=e.scrollHeight');p.wait_for_timeout(300)
 p.screenshot(path=str(A/'options-before.png'))
 box=p.locator('input[value="cheese"]').bounding_box();coords['cheese']=box
 p.locator('input[value="cheese"]').check();p.wait_for_timeout(200);p.screenshot(path=str(A/'options-selected.png'))
 coords['add']=p.locator('#addToCart').bounding_box()
 p.locator('#addToCart').click();p.wait_for_timeout(400);p.locator('#topBag').click();p.wait_for_timeout(500)
 p.screenshot(path=str(A/'cart-one.png'))
 print('cart buttons',p.locator('#cartDialog button').evaluate_all('(es)=>es.map(e=>({text:e.textContent,data:e.dataset}))'),flush=True)
 plus=p.locator('#cartItems [data-qty="1"]');coords['plus']=plus.bounding_box();plus.click();p.wait_for_timeout(200)
 p.screenshot(path=str(A/'cart-two.png'))
 p.locator('[data-close="cartDialog"]').click();p.evaluate('window.scrollTo(0,0)');p.wait_for_timeout(700)
 p.screenshot(path=str(A/'language-ar.png'));coords['language']=p.locator('#languageToggle').bounding_box()
 p.locator('#languageToggle').click();p.wait_for_timeout(400);p.screenshot(path=str(A/'language-en.png'))
 (A/'tap-coordinates.json').write_text(json.dumps(coords,indent=2));b.close()
