from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parent;A=R/'assets'
with sync_playwright() as w:
 b=w.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 p=b.new_page(viewport={'width':432,'height':768},device_scale_factor=2,locale='ar-SY')
 p.add_init_script("localStorage.setItem('ember-language-v1','ar')")
 p.goto('http://127.0.0.1:8876/offline-menu.html');p.wait_for_timeout(1500)
 p.screenshot(path=str(A/'hero.png'))
 print('buttons',p.locator('button').evaluate_all('(es)=>es.slice(0,35).map(e=>({id:e.id,text:e.textContent.slice(0,70),data:e.dataset}))'))
 print('hero',p.locator('#heroDish').bounding_box())
 p.locator('[data-category="burgers"]').click();p.wait_for_timeout(1800);p.screenshot(path=str(A/'burgers.png'))
 print('scene',p.locator('#scene-burgers').bounding_box())
 p.locator('#scene-burgers [data-product]').first.click();p.wait_for_timeout(750);p.screenshot(path=str(A/'options.png'))
 print('dialog',p.locator('#productDialog').inner_text())
 print('inputs',p.locator('#productDialog input').evaluate_all('(es)=>es.map(e=>({type:e.type,name:e.name,value:e.value,id:e.id}))'))
 b.close()
