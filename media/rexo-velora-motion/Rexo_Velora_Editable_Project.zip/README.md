# Rexo × VELORA — Arabic motion advertisement

58-second portrait motion graphics using the supplied VELORA menu and unchanged natural-speed narration. Cream/charcoal/gold art direction, Arabic typography, actual menu screenshots, product cutouts from the supplied HTML, basket quantity demonstration and language switching.

## Files and rebuild
- `build.py`: deterministic 1080×1920, 30 fps Python renderer.
- `assets/`: supplied embedded images, fonts and real browser captures.
- `voice.mp3`: original supplied narration, unchanged.
- `menu.html`: supplied source menu.
- `transcript.json`: automatic word alignment before spelling normalization.
- `delivery/timeline.json` and `.srt`: corrected phrase captions and cue sheet.
- `sound.py`: original generated ambient music and transition accents.
- `finalize.py`: mix narration/music, mux MP4, decode and inspect output.

Requires Python 3, Pillow with libraqm, NumPy, FFmpeg. Run from this folder: `python build.py`, then `python sound.py`, then `python finalize.py`. Use `python build.py --preview` for a contact sheet.

Typography: Cairo and Montserrat embedded in the user-provided HTML; retain their respective upstream font licenses if redistributing font assets separately. Product photos and menu artwork are supplied by the user; this package makes no new ownership claim over them. Music is synthesized by the included code.

QA: representative full-resolution frames and speech alignment reviewed; full video decode checked. Direct listening/playback perception was unavailable. Caption spelling was normalized from ASR and context, and should receive a listening check before a paid campaign. The original narration has not been rewritten or retimed. The pictured basket is a demonstration selection basket, as its interface says; no live order or payment backend is claimed.

Platform-safe layout is provisional; overlay controls vary between social platforms. The SRT is supplied for editing; avoid displaying it again over the burned-in captions.
